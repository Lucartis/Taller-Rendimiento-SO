/**************************************************************
		Pontificia Universidad Javeriana
	Autor: Lucas Rivera, Santiago Lemus,  Paula Malagón
	Fecha: Mayo 2024
	Materia: Sistemas Operativos
	Tema: Taller de Evaluación de Rendimiento
	Fichero: fuente de multiplicación de matrices NxN por hilos.
	Objetivo: Evaluar el tiempo de ejecución del 
					algoritmo clásico de multiplicación de matrices.
				Se implementa con la Biblioteca POSIX Pthreads
****************************************************************/
#include "Fuente_Evaluacion.h"

pthread_mutex_t MM_mutex;
double *mA, *mB, *mC;
struct timeval start, stop;

// Función para llenar la matriz con valores aleatorios
void llenar_matriz(int SZ){ 
		srand48(time(NULL)); // Inicialización de la seed para números aleatorios
		for(int i = 0; i < SZ*SZ; i++){
				mA[i] = 1.1*i; // Valores aleatorios para matriz A
				mB[i] = 2.2*i; // Valores aleatorios para matriz B 
				mC[i] = 0; // Inicialización de matriz C con ceros
		}   
}

// Función para imprimir una matriz
void print_matrix(int sz, double *matriz){
		if(sz < 12){ // Solo imprime si la matriz es de tamaño pequeño (Menor a 12)
				for(int i = 0; i < sz*sz; i++){
						if(i%sz==0) printf("\n"); // Cambio de línea para cada fila
						printf(" %.3f ", matriz[i]); // Imprime cada elemento con tres decimales
				}   
		}
		printf("\n>-------------------->\n"); 
}

// Funciones para medir el tiempo de ejecución
void inicial_tiempo(){
		gettimeofday(&start, NULL); // Obtiene el tiempo de inicio
}

void final_tiempo(){
		gettimeofday(&stop, NULL); // Obtiene el tiempo de finalización
		stop.tv_sec -= start.tv_sec; // Calcula la diferencia en segundos
		printf("\n:-> %9.0f µs\n", (double) (stop.tv_sec*1000000 + stop.tv_usec)); // Imprime el tiempo transcurrido en microsegundos
}

// Función ejecutada por cada hilo para multiplicar las matrices
void *mult_thread(void *variables){
		struct parametros *data = (struct parametros *)variables;

		int idH = data->idH; 
		int nH  = data->nH; 
		int N   = data->N; 
		int ini = (N/nH)*idH;
		int fin = (N/nH)*(idH+1); 

		for (int i = ini; i < fin; i++){ // iterar sobre las filas de la sección de la matriz
				for (int j = 0; j < N; j++){ // iterar sobre las columnas de la matriz
						double *pA, *pB, sumaTemp = 0.0; // Punteros para recorrer las matrices y variable temporal para la suma
						pA = mA + (i*N); // Puntero a la fila i de la matriz A
						pB = mB + j; // Puntero a la columna j de la matriz B
						for (int k = 0; k < N; k++, pA++, pB+=N){ // Bucle para realizar la multiplicación y suma de elementos
								sumaTemp += (*pA * *pB); // Multiplicación de elementos y acumulación en sumaTemp
						}
						mC[i*N+j] = sumaTemp; // Almacenamiento del resultado en la matriz C
				}
		}

		pthread_mutex_lock (&MM_mutex); // Bloquea el mutex antes de acceder a recursos compartidos
		pthread_mutex_unlock (&MM_mutex); // Desbloquea el mutex después de acceder a recursos compartidos
		pthread_exit(NULL); // Termina el hilo
}
