/**************************************************************
		Pontificia Universidad Javeriana
		Autor: Lucas Rivera, Santiago Lemus,  Paula Malagón
		Fecha: Mayo 2024
		Materia: Sistemas Operativos
		Tema: Taller de Evaluación de Rendimiento
		Fichero: fuente de multiplicación de matrices NxN por hilos.
		Objetivo: Evaluar el tiempo de ejecución del 
							algoritmo clásico de multiplicación de matrices.
							Se implementa con la Biblioteca POSIX Pthreads
****************************************************************/
#include "mm_clasico.h" // Incluye la cabecera mm_clasico.h que contiene las funciones y estructuras necesarias.
#include <pthread.h> // Incluye la biblioteca pthread.h para utilizar hilos.
#include <stdlib.h> // Incluye la biblioteca estándar de C para usar la función atoi().
#include <stdio.h> // Incluye la biblioteca estándar de C para entrada/salida estándar.

static double MEM_CHUNK[DATA_SIZE]; // Declara un arreglo estático de tipo double para almacenar datos.

int main(int argc, char *argv[]){
		if (argc < 3){ // Verifica si se ingresaron los argumentos necesarios.
				printf("Ingreso de argumentos \n $./ejecutable tamMatriz numHilos\n");
				return -1; // Sale del programa indicando un error.
		}
		int SZ = atoi(argv[1]); // Convierte el primer argumento a entero.
		int n_threads = atoi(argv[2]); // Convierte el segundo argumento a entero.

		pthread_t p[n_threads]; // Declara un arreglo de identificadores de hilo.
		pthread_attr_t atrMM; // Declara un atributo de hilo.

		mA = MEM_CHUNK; // Asigna el inicio del arreglo de memoria a la matriz mA.
		mB = mA + SZ*SZ; // Asigna el espacio contiguo al de mA para la matriz mB.
		mC = mB + SZ*SZ; // Asigna el espacio contiguo al de mB para la matriz mC.

		llenar_matriz(SZ); // Llena las matrices mA y mB con datos aleatorios.
		print_matrix(SZ, mA); // Imprime la matriz mA.
		print_matrix(SZ, mB); // Imprime la matriz mB.

		inicial_tiempo(); // Inicia el cronómetro para medir el tiempo de ejecución.
		pthread_mutex_init(&MM_mutex, NULL); // Inicializa el mutex utilizado para sincronizar la multiplicación de matrices.
		pthread_attr_init(&atrMM); // Inicializa el atributo de hilo.
		pthread_attr_setdetachstate(&atrMM, PTHREAD_CREATE_JOINABLE); // Configura el atributo para que los hilos sean creados de forma separada y puedan ser unidos después.

		for (int j=0; j<n_threads; j++){ // Itera sobre el número de hilos a crear.
				struct parametros *datos = (struct parametros *) malloc(sizeof(struct parametros)); // Asigna memoria para los datos de los hilos.
				datos->idH = j; // Asigna el identificador del hilo.
				datos->nH  = n_threads; // Asigna el número total de hilos.
				datos->N   = SZ; // Asigna el tamaño de la matriz.
				pthread_create(&p[j], &atrMM, mult_thread, (void *)datos); // Crea un hilo con los datos proporcionados.
		}

		for (int j=0; j<n_threads; j++) // Itera sobre los hilos creados.
				pthread_join(p[j], NULL); // Espera a que cada hilo termine su ejecución.

		final_tiempo(); // Finaliza el cronómetro y muestra el tiempo de ejecución.
		print_matrix(SZ, mC); // Imprime la matriz resultante de la multiplicación.

		pthread_attr_destroy(&atrMM); // Destruye el atributo de hilo.
		pthread_mutex_destroy(&MM_mutex); // Destruye el mutex utilizado para sincronizar la multiplicación de matrices.
		pthread_exit(NULL); // Sale del hilo principal.
}
