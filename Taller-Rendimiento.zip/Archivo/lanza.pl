#!/usr/bin/perl
#**************************************************************
#     Pontificia Universidad Javeriana
#     Autor: Lucas Rivera, Santiago Lemus,  Paula Malagón 
#     Fecha: Febrero 2024
#     Materia: Sistemas Operativos
#     Tema: Taller de Evaluación de Rendimiento
#     Fichero: script automatización ejecución por lotes 
#****************************************************************/

# Define el directorio actual
$Path = `pwd`;
chomp($Path);

# Nombre del ejecutable
$Nombre_Ejecutable = ("e_clasico","e_trans");

# Tamaños de matriz y números de hilos a probar
@Size_Matriz = ("200","400","800","1000","1200","1400");
@Num_Hilos = (1,2,4,6,8);

# Número de repeticiones
$Repeticiones = 30;

# Bucle para cada tamaño de matriz
foreach $nombre (@Nombre_Ejecutable){
foreach $size (@Size_Matriz){
	foreach $hilo (@Num_Hilos) {
		# Nombre del archivo de salida
		$file = "$Path/$nombre-".$size."-Hilos-".$hilo.".dat";
		for ($i=0; $i<$Repeticiones; $i++) {
			# Llamada al ejecutable (comentada)
			# Imprime la llamada al ejecutable
			printf("\"$Path/$nombre\" $size $hilo >> \"$file\"");
			printf("$Path/$nombre $size $hilo \n");
		}
		close($file);
		$p=$p+1;
	}
}
}